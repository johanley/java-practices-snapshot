/** 
Show a simple 'About' box, displaying information about the application.
*/
package hirondelle.movies.about;