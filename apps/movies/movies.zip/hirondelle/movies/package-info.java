/** 
 <b>Launch point of the application.</b>
*/
package hirondelle.movies;