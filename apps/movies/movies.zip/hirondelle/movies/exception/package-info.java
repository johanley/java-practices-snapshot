/** 
 Classes related to exceptions.
*/
package hirondelle.movies.exception;