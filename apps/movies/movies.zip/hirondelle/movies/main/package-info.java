/** 
  <b>Main window</b> in the application.
  This app has only one main window, from which all dialogs and operations are launched (with 
  the exception of the login screen). 
*/
package hirondelle.movies.main;