/**
Utilities for Swing user interfaces. 
*/
package hirondelle.movies.util.ui;