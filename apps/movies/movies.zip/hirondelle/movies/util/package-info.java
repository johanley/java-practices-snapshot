/** 
Simple utility classes.
*/
package hirondelle.movies.util;