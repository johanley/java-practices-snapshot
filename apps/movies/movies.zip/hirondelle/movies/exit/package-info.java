/** 
Close the application and exit the JVM.
*/
package hirondelle.movies.exit;