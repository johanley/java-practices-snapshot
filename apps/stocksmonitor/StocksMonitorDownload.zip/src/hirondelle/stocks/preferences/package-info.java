/** Edit user preferences. */
package hirondelle.stocks.preferences;