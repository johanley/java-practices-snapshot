/** Table for listing, sorting, and filtering stock quotes. */
package hirondelle.stocks.table;