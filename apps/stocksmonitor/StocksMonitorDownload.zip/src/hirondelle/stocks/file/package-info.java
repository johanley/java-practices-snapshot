/** File menu actions. */
package hirondelle.stocks.file;