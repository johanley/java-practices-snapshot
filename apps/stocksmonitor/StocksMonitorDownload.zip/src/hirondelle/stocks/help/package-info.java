/** Help menu actions. */
package hirondelle.stocks.help;