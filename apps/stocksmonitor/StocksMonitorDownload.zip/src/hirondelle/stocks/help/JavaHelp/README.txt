Contains a help system developed using Sun's JavaHelp tool.

To generate the text search directory:
- delete JavaHelpSearch dir
- run jhindexer against the Topics dir, as in
C:\johanley\Projects\StocksMonitor\help>c:\johanley\projects\libraries\javahelp-1_1_3\jh1.1.3\javahelp\bin\jhindexer Topics

