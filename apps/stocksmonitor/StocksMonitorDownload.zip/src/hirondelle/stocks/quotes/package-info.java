/** Fetch and display stock quotes. */
package hirondelle.stocks.quotes;