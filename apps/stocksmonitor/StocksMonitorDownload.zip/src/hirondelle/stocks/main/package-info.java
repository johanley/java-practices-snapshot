/** Launch point and main screen in the application. */
package hirondelle.stocks.main;