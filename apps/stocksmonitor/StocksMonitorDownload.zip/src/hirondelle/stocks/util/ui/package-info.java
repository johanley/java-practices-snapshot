/** General utility classes related to Swing. */
package hirondelle.stocks.util.ui;