/** Utility classes. */
package hirondelle.stocks.util;