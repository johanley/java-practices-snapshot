/** Edit and store portfolios. */
package hirondelle.stocks.portfolio;